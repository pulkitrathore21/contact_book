from flask import Flask, Blueprint
from flask_sqlalchemy import SQLAlchemy
from app import ContactApi
from flask_migrate import Migrate
from app.models import db


app = Flask(__name__)


# postgresql://postgres:postgres@   localhost:5432/cars_api
# "postgresql+psycopg2://hello_flask:hello_flask@localhost/report_builder_muse"
app.config[
    "SQLALCHEMY_DATABASE_URI"
] = "postgresql+psycopg2://admin:1234@localhost:5433/contact"
# app.config["SQLALCHEMY_DATABASE_URI"]="postgresql://admin:1234@127.0.0.1:5433/contact"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False


app.register_blueprint(ContactApi.apis)
# app.register_blueprint(apis)


app.app_context().push()
db.__init__(app)
from flask_sqlalchemy import SQLAlchemy


# migrate = Migrate(app, db)


if __name__ == "__main__":
    app.run(debug=True)
