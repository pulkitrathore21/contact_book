# from fate import db
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Contacts(db.Model):
    __tablename__ = "contactbook"
    print("database")
    name = db.Column(db.Text, nullable=False)
    number = db.Column(db.String(50), primary_key=True)
    profile_pic = db.Column(db.String)
    email = db.Column(db.Text)
    dob = db.Column(db.Text)
    print("end database")

    # def __init__(self,name,number,profile_pic,email,dob):
    #     self.name=name
    #     self.number=number
    #     self.profile_pic=profile_pic
    #     self.email=email
    #     self.dob=dob

    # def __repr__(self):
    #     return f"{self.name},{self.number},{self.email}"
