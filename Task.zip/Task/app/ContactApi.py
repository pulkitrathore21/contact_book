from flask import Blueprint, request, jsonify

# from .logic import *
import json
from flask import jsonify
import base64
from .models import Contacts, db
from sqlalchemy.exc import IntegrityError
from flask import Blueprint, request, jsonify
import base64

# ContactApi.py
apis = Blueprint("contact_book", __name__)


@apis.route("/contact", methods=["POST"])
def creation_contact():
    email = None
    pic = None
    dob = None

    name = request.form.get("name")
    number = request.form.get("number")
    pic = pic or request.files.get("pic")
    email = email or request.form.get("email")
    dob = dob or request.form.get("dob")
    result = create_new_contact(name, number, pic, email, dob)
    print(result)

    # # result=creating_contact(name,number,pic,email,dob)
    # # if len(number)!=10:
    # #     raise ContactException(f"Contact number's length should be 10",400)
    # # if number.isdigit()!=True:
    # #     raise ContactException(f"String found an alphabets")

    return jsonify({"success": True, "message": "contact saved successfully"})


@apis.route("/contacts", methods=["GET"])
def getting_data():
    name = None
    number = None
    name = name or request.form.get("name")
    number = number or request.form.get("number")
    result = get_contact(name, number)
    # all=Contacts.query.all()
    return result


@apis.route("/contact/deleted", methods=["delete"])
def delete_contact():
    name = None
    number = None
    name = name or request.form.get("name")
    number = number or request.form.get("number")
    result = delete_from_contact_book(name, number)
    return result


@apis.route("/contact", methods=["PATCH"])
def update_contact():
    name = None
    number = None
    email = None
    dob = None
    name = name or request.form.get("name")
    number = number or request.form.get("number")
    email = email or request.form.get("email")
    dob = dob or request.form.get("dob")
    result = update_existing_contact(name, number, dob, email)
    return result


class ContactException(Exception):
    def __init__(self, message, code=400):
        self.message = message
        self.code = code


@apis.errorhandler(Exception)
def handle_exception(e):
    return {"success": False, "error": str(e)}, 400


def create_new_contact(name, number, pic, email, dob):
    my_string = None
    if len(number) != 10 and number.isdigit() != True:
        raise ContactException("check you numbers length or alphabet found", 406)
    if pic:
        my_string = base64.b64encode(pic.read())
    try:
        into_db = Contacts(
            name=name.capitalize(),
            number=number,
            profile_pic=str(my_string) or pic,
            dob=dob,
            email=email,
        )
        db.session.add(into_db)
        db.session.commit()
        return jsonify({"success": True, "message": "Saved successfully"})
    except IntegrityError as e:  # proves the original exception
        db.session.rollback()
        return {"success": False, "error": "number is already in contact book"}, 200


def get_contact(name, number):
    if name is not None:
        match_contact = Contacts.query.filter_by(name=name.capitalize()).first()
        if match_contact:
            return jsonify(
                {
                    "success": True,
                    "message": "match_data found",
                    "name": match_contact.name,
                    "number": match_contact.number,
                }
            )
        raise ContactException(f"No contact found of this name", 204)
    if number is not None:
        match_contact = Contacts.query.filter_by(number=number).first()
        if match_contact:
            return (
                jsonify(
                    {
                        "success": True,
                        "message": "match number found",
                        "name": match_contact.name,
                        "number": match_contact.number,
                    }
                ),
                200,
            )
        raise ContactException("no contact found of this number", 204)
    all_contacts = Contacts.query.order_by(Contacts.name).paginate(
        per_page=2,
    )

    if all_contacts:
        l1 = []
        for contact in all_contacts:
            # print(contact.pic)
            cont = {}
            cont["name"] = contact.name
            cont["number"] = contact.number
            cont["email"] = contact.email
            cont["pic"] = contact.profile_pic
            cont["dob"] = contact.dob
            l1.append(cont)
        # with open("student.json", "w") as write_file:
        with open("initial_data.json", "w") as write_file:
            json.dump(l1, write_file, indent=4)

        return jsonify({"success": True, "contacts": l1}), 200


def delete_from_contact_book(name, number):
    if name is not None:
        match_contact = Contacts.query.filter_by(name=name.capitalize()).first()
        if match_contact:
            db.session.delete(match_contact)
            db.session.commit()
            return (
                jsonify({"success": True, "message": "contact deleted successfully"}),
                200,
            )
        raise ContactException("No name found", 204)
    if number is not None:
        match_contact = Contacts.query.filter_by(number=number).first()
        if match_contact:
            db.session.delete(match_contact)
            db.session.commit()
            return (
                jsonify({"success": True, "message": "contact deleted successfully"}),
                200,
            )
        raise ContactException("No number found", 204)


def update_existing_contact(name, number, email, dob):
    if name is not None:
        match_contact = Contacts.query.filter_by(name=name.capitalize()).first()
        print(match_contact)
        if match_contact:
            if number is not None:
                match_contact.number = number
            if email is not None:
                match_contact.email = email
            if dob is not None:
                match_contact.dob = dob
            db.session.commit()
            return (
                jsonify({"success": True, "message": "Contact updated successfully"}),
                200,
            )

        raise ContactException("contact not found", 204)
    raise ContactException("No contact found of this name", 204)
